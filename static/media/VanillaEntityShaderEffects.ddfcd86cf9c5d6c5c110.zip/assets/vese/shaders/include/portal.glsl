#moj_import <minecraft:matrix.glsl>

const vec3[] VOID_COLORS = vec3[](
    vec3(0.022087, 0.098399, 0.110818),
    vec3(0.011892, 0.095924, 0.089485),
    vec3(0.027636, 0.101689, 0.100326),
    vec3(0.046564, 0.109883, 0.114838),
    vec3(0.064901, 0.117696, 0.097189),
    vec3(0.063761, 0.086895, 0.123646),
    vec3(0.084817, 0.111994, 0.166380),
    vec3(0.097489, 0.154120, 0.091064),
    vec3(0.106152, 0.131144, 0.195191),
    vec3(0.097721, 0.110188, 0.187229),
    vec3(0.133516, 0.138278, 0.148582),
    vec3(0.070006, 0.243332, 0.235792),
    vec3(0.196766, 0.142899, 0.214696),
    vec3(0.047281, 0.315338, 0.321970),
    vec3(0.204675, 0.390010, 0.302066),
    vec3(0.080955, 0.314821, 0.661491)
);

const mat4 SCALE_TRANSLATE = mat4(
    0.5, 0.0, 0.0, 0.25,
    0.0, 0.5, 0.0, 0.25,
    0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 1.0
);

mat4 end_portal_layer(float layer, float GameTime) {
    mat4 translate = mat4(
        1.0, 0.0, 0.0, 17.0 / layer,
        0.0, 1.0, 0.0, (2.0 + layer / 1.5) * (GameTime * 1.5),
        0.0, 0.0, 1.0, 0.0,
        0.0, 0.0, 0.0, 1.0
    );

    mat2 rotate = mat2_rotate_z(radians((layer * layer * 4321.0 + layer * 9.0) * 2.0));

    mat2 scale = mat2((4.5 - layer / 4.0) * 2.0);

    return mat4(scale * rotate) * translate * SCALE_TRANSLATE;
}

float voidMask(vec2 coord, vec2 size, float GameTime) {

    int width = int(size.x);
    int height = int(size.y);
    
    //int height = int(width * screenSize.y / screenSize.x);

    int x = (int(coord.x) % width);
    int y = (int(coord.y - 4000 * GameTime) % height);

    int pixel_size = 3;

    x -= (x % pixel_size);
    y -= (y % pixel_size);

    // Quick and dirty noise algorithm from https://stackoverflow.com/a/17075605
    int seed = x * 73;
    seed ^= 0xE56FAA12;
    seed += y * 179;
    seed ^= 0x69628A2D;
    float result = float(int(seed%201 + 201)%201-100)/100.0f;

    if (result > 0.99f)
    {
      return 1.0f;
    }

    // Quick and dirty noise algorithm from https://stackoverflow.com/a/17075605
    seed = x * 73;
    seed ^= 0xE56FAA12;
    seed += (y + pixel_size) * 179;
    seed ^= 0x69628A2D;
    result = float(int(seed%201 + 201)%201-100)/100.0f;

    if (result > 0.99f)
    {
      return 0.5f;
    }

    // Quick and dirty noise algorithm from https://stackoverflow.com/a/17075605
    seed = x * 73;
    seed ^= 0xE56FAA12;
    seed += (y + pixel_size + pixel_size) * 179;
    seed ^= 0x69628A2D;
    result = float(int(seed%201 + 201)%201-100)/100.0f;

    if (result > 0.99f)
    {
      return 0.1f;
    }

    return 0.0f;
}