
float sequenceMask(int sequence, bool invert, int speed, float time)
{
  int activeSequence = int(t * 8);
  int nextSequence = 

  return ((activeSequence == sequence) != invert ? 1.0 : 0.0);
}