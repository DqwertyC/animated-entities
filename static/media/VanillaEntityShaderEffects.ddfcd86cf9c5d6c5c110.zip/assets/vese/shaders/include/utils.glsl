#version 150

ivec4 rgbFloatToInt(vec4 inColor)
{
  return ivec4(int(255*inColor.r),int(255*inColor.g),int(255*inColor.b),int(255*inColor.a));
}

ivec2 coordFloatToInt(vec2 inPos, ivec2 size)
{
  return ivec2(int(size.x*inPos.x),int(size.y*inPos.y));
}

vec2 coordIntToFloat(ivec2 inCoord, ivec2 size)
{
  return vec2(inCoord.x / float(size.x), inCoord.y / float(size.y));
}