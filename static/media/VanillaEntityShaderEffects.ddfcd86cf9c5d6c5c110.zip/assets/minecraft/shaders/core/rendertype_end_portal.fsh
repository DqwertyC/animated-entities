#version 150

#moj_import <minecraft:matrix.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <vese:portal.glsl>

in vec4 texProj0;

out vec4 fragColor;

void main() {
    vec3 void_color = voidMask(gl_FragCoord.xy, ScreenSize, GameTime) * VOID_COLORS[0];

    for (int i = 0; i < PORTAL_LAYERS; i++) {
        void_color += voidMask((gl_FragCoord * end_portal_layer(float(i + 1), GameTime)).xy, ScreenSize, GameTime) * VOID_COLORS[i];
    }

    fragColor = vec4(void_color, 1.0);
}
